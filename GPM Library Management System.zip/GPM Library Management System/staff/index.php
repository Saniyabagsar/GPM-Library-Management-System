<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

		

	<title> GPM Online Library Management System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
	nav
{
    float: right;
    word-spacing: 30px;
    padding: 20px;
}

nav li
{
    display: inline-block;
    line-height: 100px;
}
	</style>
</head>
<body>
<div class="wrapper">
<header>
    <div class="logo">
	<img src="images/blogo.png">
	<h1 style="color: white ;">GPM LIBRARY MANAGEMENT SYSTEM</h1>
    </div>
	<nav> 
         <ul>
         	<li><a href="index.html">HOME</a></li>
         	<li><a href="">BOOKS</a></li>
         	<li><a href="student_login.html">STUDENT_LOGIN</a></li>
         	<li><a href="student_registration.html">REGISTRATION</a></li>
         	<li><a href="">FEEDBACK</a></li>
         	<li><a href="">ABOUT_US</a></li>
         </ul>
	</nav>
</header>

<section>
	<div class="sec_img">
	<br>
	<div class="box">
		<br><br><br><br>
	<h1 style="text-align: center; font-size: 35px;"> Welcome to library</h1>
    </div>
    </div>

</section>

<footer>
	<p style="color: white; text-align:center;">
		<br>
		Email :  gpmlibrary@gmail.com<br><br>
		Mobile : +9977665554

	</p>
</footer>
</div>
</body>
</html>