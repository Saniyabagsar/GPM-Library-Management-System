
<?php 
include "connection.php";
session_start();

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   


 
  <title>Student Login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  
  

</head>
<body>


<nav class="navbar navbar-inverse ">
		<div class="container-fluid">
     <div class="navbar-header active">
	
		
	<a class="navbar-brand">GPM LIBRARY MANAGEMENT SYSTEM</a>
    </div>
	 
         <ul class="nav navbar-nav">
         	<li><a href="index.php">HOME</a></li>
         	<li><a href="books.php">BOOKS</a></li>
     
         	<li><a href="feedback.php">FEEDBACK</a></li>
         	<li><a href="aboutus.php">ABOUT_US</a></li>
           <li><a href="profile.php">PROFILE</a></li><!---- Demo Profile--------------->

           <li><a href="fines.php">FINES</a></li>


         </ul>
         <?php
          if(isset($_SESSION['login_user']))
          {
            ?>
            
              <ul class="nav navbar-nav navbar-right">
                <li><a href="">
                 <div style="color:white;">
              <?php 
                echo "Welcome ".$_SESSION['login_user'];
              ?>
                
              </div>
               </a> </li>


           
                        <ul class="nav navbar-nav navbar-right">

          <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"> LOGOUT</span></a></li>
           <?php
          }
          else
          {
            ?>
            <ul class="nav navbar-nav navbar-right">
             <li><a href="login.php"><span class="glyphicon 
              glyphicon-log-in"> LOGIN</span></a></li>

          <li><a href="student_registration.php"><span class="glyphicon glyphicon-user"> SIGN_UP</span></a></li>
         </ul>
            
          <?php
          }

         ?>
          
      </div>
      </nav>
 <?php
             if(isset($_SESSION['login_user']))
             {
              $day=0;
              $exp='<p style="color:yellow;background-color:red;">EXPIRED</p>';
              $res = mysqli_query($db,"SELECT * FROM `issue_book` where username='$_SESSION[login_user]' and approved='$exp';");
              while($row = mysqli_fetch_assoc($res))
              {
                $d = strtotime($row['returnd']);
                $c = strtotime(date("Y-m-d"));
               $diff = $c - $d;
               if($diff>0)
               {

               
               $day= $day+floor($diff/(60*60*24));

               }
                
              }

                             $_SESSION['fine'] = $day*5;


             }

       ?>

    </body>
    </html>
      
		